//obejetivo - quando o usuarios clicar no botao mostrar mais, os projetos devem ser exibidos
//Passo 1 - pegar o botão mostrar mais no JS pra poder verificar quando o usuário clicar em cima dele
const botaomostrarprojetos = document.querySelector('.btn-mostrar-projetos');
const projetosinativos = documet.queryselectorall(`.projeto:not(.ativo)')


botaomostrarprojetos.addeveListener('click', () => {
//passo 3 - adicionar a classe "ativo" nos porjetos escondidos

projetosinativos.forEach(projetoinativo =>{(projetoinativo.classlist.add(`ativo`.);
 
})

//objetivo 2 - esconder botão de mostrar
//passo 1 - pegar botão e esconder ele 
botaomostrarporjetos.classlist.add("remover");
  
});
